import pygame

screenshake = pygame.Vector2(0, 0)
cam = pygame.Vector2(0, 0)
camSize = pygame.Vector2(0, 0)